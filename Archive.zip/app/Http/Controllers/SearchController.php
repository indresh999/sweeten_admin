<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Models\Item;
use App\Models\AppOwnerUser;
use Illuminate\Support\Facades\DB;

class SearchController extends Controller
{
   
     public function suggestions(Request $request)
    {
        $q = $request->input('q');
        $lat = $request->input('lat');
        $lng = $request->input('lng');
    
        if (!$q || strlen($q) < 2) {
            return response()->json([
                'shops' => [],
                'items' => []
            ]);
        }
    
        /*
        |--------------------------------------------------------------------------
        | Nearby Shops Suggestions
        |--------------------------------------------------------------------------
        */
       $shops = AppOwnerUser::select(
                'shop_id',
                'restaurant_name',
                DB::raw("(6371 * acos(
                    cos(radians($lat)) *
                    cos(radians(latitude)) *
                    cos(radians(longitude) - radians($lng)) +
                    sin(radians($lat)) *
                    sin(radians(latitude))
                )) AS distance"),
                DB::raw("
                    CASE
                        WHEN restaurant_name LIKE '$q%' THEN 1
                        WHEN restaurant_name LIKE '%$q%' THEN 2
                        ELSE 3
                    END as relevance
                ")
            )
            ->orderBy('relevance')
            ->orderBy('distance')
            ->limit(20)
            ->get();
    
        /*
        |--------------------------------------------------------------------------
        | Item Suggestions
        |--------------------------------------------------------------------------
        */
       
        $items = Item::with('owner:shop_id,restaurant_name')
            ->where(function ($query) use ($q) {
                $query->where('item_name', 'LIKE', "$q%")
                    ->orWhere('item_name', 'LIKE', "%$q%");
            })
            ->select('id', 'item_name', 'shop_id', 'images')
            ->limit(5)
            ->get()
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'item_name' => $item->item_name,
                    'shop_name' => $item->owner->restaurant_name ?? '',
                    'image' => $item->image_urls[0] ?? null
                ];
            });

    
        return response()->json([
            'shops' => $shops,
            'items' => $items
        ]);
    }
    
    public function search(Request $request)
{
    $q = $request->input('q');
    $lat = $request->input('lat');
    $lng = $request->input('lng');

    /*
    |--------------------------------------------------------------------------
    | Shops Search
    |--------------------------------------------------------------------------
    */
    $shops = AppOwnerUser::select(
            'shop_id',
            'restaurant_name',
            'city',
            DB::raw("(6371 * acos(
                cos(radians($lat)) *
                cos(radians(latitude)) *
                cos(radians(longitude) - radians($lng)) +
                sin(radians($lat)) *
                sin(radians(latitude))
            )) AS distance")
        )
        ->where(function ($query) use ($q) {
            $query->whereRaw("MATCH(restaurant_name, city) AGAINST(? IN BOOLEAN MODE)", [$q.'*'])
                  ->orWhere('restaurant_name', 'LIKE', "%$q%");
        })
        ->having("distance", "<", 50)
        ->orderBy("distance")
        ->limit(20)
        ->get();

    /*
    |--------------------------------------------------------------------------
    | Items Search
    |--------------------------------------------------------------------------
    */
    $items = Item::with(['owner', 'defaultVariant'])
        ->where(function ($query) use ($q) {
            $query->whereRaw("MATCH(item_name, description) AGAINST(? IN BOOLEAN MODE)", [$q.'*'])
                  ->orWhere('item_name', 'LIKE', "%$q%");
        })
        ->limit(30)
        ->get();

    return response()->json([
        'shops' => $shops,
        'items' => $items
    ]);
}
}