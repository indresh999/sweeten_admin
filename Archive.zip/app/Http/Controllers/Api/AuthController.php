<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AppUser;
use App\Mail\SendOtpMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Carbon\Carbon;

class AuthController extends Controller
{
    // SEND OTP
    public function sendOtp(Request $request)
    {
        $request->validate([
            'email' => 'required|email'
        ]);

        $email = $request->email;
        $otp = rand(1000, 9999);

        $user = AppUser::firstOrCreate([
            'email' => $email
        ]);

        $user->otp = $otp;
        $user->otp_expires_at = Carbon::now()->addMinutes(10);
        $user->save();

        Mail::to($email)->send(new SendOtpMail($otp, $email));

        return response()->json([
            'status' => true,
            'message' => 'OTP sent successfully'
        ]);
    }

    // VERIFY OTP
    public function verifyOtp(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'otp' => 'required'
        ]);

        $user = AppUser::where('email', $request->email)
            ->where('otp', $request->otp)
            ->first();

        if (!$user) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid OTP'
            ], 400);
        }

        if (Carbon::now()->gt($user->otp_expires_at)) {
            return response()->json([
                'status' => false,
                'message' => 'OTP expired'
            ], 400);
        }

        // Generate token
        $token = Str::random(60);

        $user->api_token = $token;
        $user->otp = null;
        $user->otp_expires_at = null;
        $user->is_verified = 1;
        $user->save();

        return response()->json([
            'status' => true,
            'token' => $token,
            'user' => $user
        ]);
    }

    // LOGOUT
    public function logout(Request $request)
    {
        $token = $request->header('Authorization');

        $user = AppUser::where('api_token', $token)->first();

        if ($user) {
            $user->api_token = null;
            $user->save();
        }

        return response()->json([
            'status' => true,
            'message' => 'Logged out'
        ]);
    }

    // UPDATE PROFILE
    public function updateProfile(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id'  => 'required|exists:app_users,id',
            'full_name'=> 'nullable|string',
            'dob'      => 'nullable|date',
            'gender'   => 'nullable|in:male,female,other',
            'picture'  => 'nullable|string',
            'state'    => 'nullable|string',
            'city'     => 'nullable|string',
            'pincode'  => 'nullable|string|max:10',
            'address'  => 'nullable|string',
            'lat'      => 'nullable|numeric',
            'lng'      => 'nullable|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $user = AppUser::find($request->user_id);

        $user->update([
            'full_name' => $request->full_name,
            'dob' => $request->dob,
            'gender' => $request->gender,
            'picture' => $request->picture,
            'state' => $request->state,
            'city' => $request->city,
            'pincode' => $request->pincode,
            'address' => $request->address,
            'lat' => $request->lat,
            'lng' => $request->lng,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Profile updated successfully',
            'user' => $user
        ]);
    }
}