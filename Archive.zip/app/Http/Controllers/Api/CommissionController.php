<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Item;
use App\Models\ItemCategory;
use App\Models\ItemSubcategory;
use Illuminate\Http\Request;

class CommissionController extends Controller
{
   public function getCommission(Request $request)
{
    $categoryId = $request->category_id;
    $subcategoryId = $request->subcategory_id;

    if ($subcategoryId) {
        $sub = ItemSubcategory::find($subcategoryId);
        if ($sub && $sub->commission_percent) {
            return response()->json([
                'status' => true,
                'level' => 'Subcategory',
                'commission_percent' => $sub->commission_percent,
                'commission_type' => $sub->commission_type,
            ]);
        }
    }

    if ($categoryId) {
        $cat = ItemCategory::find($categoryId);
        if ($cat && $cat->commission_percent) {
            return response()->json([
                'status' => true,
                'level' => 'Category',
                'commission_percent' => $cat->commission_percent,
                'commission_type' => $cat->commission_type,
            ]);
        }
    }

    return response()->json([
        'status' => true,
        'level' => 'Default',
        'commission_percent' => 10,
        'commission_type' => 'percent',
    ]);
}
}