<div class="container">
    <div class="row">
            <div class="col-lg-12">
                <img src="{{asset('images/landing-pages/images/home-2/banner-contact.webp')}}" alt="" class="img-fluid mb-4 pb-3">
            </div>
            <!-- <div class="col-lg-7 col-md-12 text-lg-start text-center">
                <p class="text-primary text-uppercase">
                contact
                </p>
                <h2>Let’s Stay <br><span class="text-primary">In Touch</span></h2>
            </div>
            <div class="col-lg-5 contact-detail mt-4 mt-lg-0">
                <h5 class="mb-2">Themes, E-commerce website,
                    Dashboard and Apps.</h5>
                    <p class="mb-2">contact@hopeui.com</p>
                    <p>(239) 555-0108</p>
            </div> -->
            <div class="col-lg-7 col-md-12 text-lg-start text-center pt-lg-2 pt-0">
                <div class="text-primary text-uppercase sub-title mb-2">
                contact
                </div>
                <h2 class="mb-0">Let’s Stay <br><span class="text-primary">In Touch</span></h2>
            </div>
            <div class="col-lg-5 contact-detail mt-4 mt-lg-0 pt-lg-2 pt-0">
                <h5 class="mb-4">Themes, E-commerce website,
                    Dashboard and Apps.</h5>
                    <h6 class="mb-3">contact@hopeui.com</h6>
                    <h6 class="mb-0">(239) 555-0108</h6>
            </div>
        </div>
    </div>
