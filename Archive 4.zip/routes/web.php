<?php

// Controllers
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\Security\RolePermission;
use App\Http\Controllers\Security\RoleController;
use App\Http\Controllers\Security\PermissionController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AppUserController;
use App\Http\Controllers\AdminOrderController;
use App\Http\Controllers\DeliveryBoyAdminController;
use App\Http\Controllers\AdminItemCategoryController;
use App\Http\Controllers\AdminItemSubcategoryController;
use App\Http\Controllers\AdminItemController;
use App\Http\Controllers\Admin\AdminCommissionController;
use Illuminate\Support\Facades\Artisan;
// Packages
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DeliveryChargeController;
use App\Http\Controllers\Admin\PlatformFeeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

require __DIR__.'/auth.php';

Route::get('/storage', function () {
    Artisan::call('storage:link');
});



Route::prefix('admin')->group(function(){

Route::get('delivery-charge',[DeliveryChargeController::class,'index'])->name('delivery-charge.index');

Route::get('delivery-charge/create',[DeliveryChargeController::class,'create'])->name('delivery-charge.create');

Route::post('delivery-charge/store',[DeliveryChargeController::class,'store'])->name('delivery-charge.store');

Route::get('delivery-charge/edit/{id}',[DeliveryChargeController::class,'edit'])->name('delivery-charge.edit');

Route::post('delivery-charge/update/{id}',[DeliveryChargeController::class,'update'])->name('delivery-charge.update');

Route::get('delivery-charge/delete/{id}',[DeliveryChargeController::class,'destroy'])->name('delivery-charge.delete');

});


Route::prefix('admin')->group(function(){

    Route::get('category-commission/{id}',
    [AdminCommissionController::class,'editCategoryCommission']);

    Route::post('category-commission/{id}',
    [AdminCommissionController::class,'updateCategoryCommission'])
    ->name('admin.category.commission.update');

    Route::get('subcategory-commission/{id}',
    [AdminCommissionController::class,'editSubcategoryCommission']);

    Route::post('subcategory-commission/{id}',
    [AdminCommissionController::class,'updateSubcategoryCommission'])
    ->name('admin.subcategory.commission.update');

    Route::get('item-commission/{id}',
    [AdminCommissionController::class,'editItemCommission']);

    Route::post('item-commission/{id}',
    [AdminCommissionController::class,'updateItemCommission'])
    ->name('admin.item.commission.update');
});

//Landing-Pages Routes
Route::group(['prefix' => 'landing-pages'], function() {
Route::get('index',[HomeController::class, 'landing_index'])->name('landing-pages.index');
Route::get('blog',[HomeController::class, 'landing_blog'])->name('landing-pages.blog');
Route::get('blog-detail',[HomeController::class, 'landing_blog_detail'])->name('landing-pages.blog-detail');
Route::get('about',[HomeController::class, 'landing_about'])->name('landing-pages.about');
Route::get('contact',[HomeController::class, 'landing_contact'])->name('landing-pages.contact');
Route::get('ecommerce',[HomeController::class, 'landing_ecommerce'])->name('landing-pages.ecommerce');
Route::get('faq',[HomeController::class, 'landing_faq'])->name('landing-pages.faq');
Route::get('feature',[HomeController::class, 'landing_feature'])->name('landing-pages.feature');
Route::get('pricing',[HomeController::class, 'landing_pricing'])->name('landing-pages.pricing');
Route::get('saas',[HomeController::class, 'landing_saas'])->name('landing-pages.saas');
Route::get('shop',[HomeController::class, 'landing_shop'])->name('landing-pages.shop');
Route::get('shop-detail',[HomeController::class, 'landing_shop_detail'])->name('landing-pages.shop-detail');
Route::get('software',[HomeController::class, 'landing_software'])->name('landing-pages.software');
Route::get('startup',[HomeController::class, 'landing_startup'])->name('landing-pages.startup');
});

//UI Pages Routs
//Route::get('/', [HomeController::class, 'uisheet'])->name('uisheet');
 Route::get('/', [HomeController::class, 'signin'])->name('auth.signin');

Route::group(['middleware' => 'auth'], function () {
    // Permission Module
    Route::get('/role-permission',[RolePermission::class, 'index'])->name('role.permission.list');
    Route::resource('permission',PermissionController::class);
    Route::resource('role', RoleController::class);

    // Dashboard Routes
    Route::get('/dashboard', [HomeController::class, 'index'])->name('dashboard');

    Route::get('/shops/{id}', [ShopController::class, 'show'])->name('shops.show');
    Route::put('/shops/{id}', [ShopController::class, 'update'])->name('shops.update');
    Route::resource('users', UserController::class);
    Route::resource('app-users', AppUserController::class);

    Route::get('/shops', [ShopController::class, 'index'])->name('shops');

    Route::get('/orders', [AdminOrderController::class, 'index'])->name('orders');
    Route::get('/orders/{id}', [AdminOrderController::class, 'show'])->name('orders.show');

 Route::prefix('admin/delivery')->name('admin.delivery.')->group(function () {

    Route::get('/pending-documents', [DeliveryBoyAdminController::class, 'pendingDocuments'])
        ->name('pending');

    Route::get('/document/{id}', [DeliveryBoyAdminController::class, 'documentShow'])
        ->name('document.show');

    Route::post('/document/{id}/verify', [DeliveryBoyAdminController::class, 'verifyDocument'])
        ->name('document.verify');

    Route::get('/boys', [DeliveryBoyAdminController::class, 'list'])
        ->name('boys');

    Route::get('/toggle/{id}', [DeliveryBoyAdminController::class, 'toggleActive'])
        ->name('toggle');

    Route::get('/profile/{id}', [DeliveryBoyAdminController::class, 'profile'])
        ->name('profile');

    // Orders list
    Route::get('/orders/{id}', [DeliveryBoyAdminController::class, 'orders'])
        ->name('orders');

    // Order details
    Route::get('/order/details/{id}', [DeliveryBoyAdminController::class, 'orderDetails'])
        ->name('order.details');

        // Earnings Page
Route::get('/earnings/{id}', [DeliveryBoyAdminController::class, 'earnings'])
    ->name('earnings');

// Task Timeline
Route::get('/timeline/{orderId}', [DeliveryBoyAdminController::class, 'timeline'])
    ->name('timeline');
});
});

Route::prefix('admin')->name('admin.')->group(function () {
    Route::resource('item-categories', \App\Http\Controllers\AdminItemCategoryController::class);
    Route::resource('items', \App\Http\Controllers\AdminItemController::class);

    Route::resource(
    'item-subcategories',
    \App\Http\Controllers\AdminItemSubcategoryController::class)->names('item-subcategories');

});


Route::prefix('admin')
    ->name('admin.')
    ->group(function () {

        Route::get(
            'get-subcategories/{categoryId}',
            [AdminItemController::class, 'getSubcategories']
        )->name('get-subcategories');

        Route::resource('items', AdminItemController::class);
    });
Route::get(
    '/admin/get-subcategories/{categoryId}',
    [AdminItemController::class, 'getSubcategories']
)->name('admin.get-subcategories');

Route::resource('admin/items', AdminItemController::class);


//App Details Page => 'Dashboard'], function() {
Route::group(['prefix' => 'menu-style'], function() {
    //MenuStyle Page Routs
    Route::get('horizontal', [HomeController::class, 'horizontal'])->name('menu-style.horizontal');
    Route::get('dual-horizontal', [HomeController::class, 'dualhorizontal'])->name('menu-style.dualhorizontal');
    Route::get('dual-compact', [HomeController::class, 'dualcompact'])->name('menu-style.dualcompact');
    Route::get('boxed', [HomeController::class, 'boxed'])->name('menu-style.boxed');
    Route::get('boxed-fancy', [HomeController::class, 'boxedfancy'])->name('menu-style.boxedfancy');
});

//App Details Page => 'special-pages'], function() {
Route::group(['prefix' => 'special-pages'], function() {
    //Example Page Routs
    Route::get('billing', [HomeController::class, 'billing'])->name('special-pages.billing');
    Route::get('calender', [HomeController::class, 'calender'])->name('special-pages.calender');
    Route::get('kanban', [HomeController::class, 'kanban'])->name('special-pages.kanban');
    Route::get('pricing', [HomeController::class, 'pricing'])->name('special-pages.pricing');
    Route::get('rtl-support', [HomeController::class, 'rtlsupport'])->name('special-pages.rtlsupport');
    Route::get('timeline', [HomeController::class, 'timeline'])->name('special-pages.timeline');
});

Route::prefix('admin')->group(function(){

    Route::get('platform-fee', [PlatformFeeController::class,'index'])->name('platform-fee.index');
    Route::get('platform-fee/create', [PlatformFeeController::class,'create'])->name('platform-fee.create');
    Route::post('platform-fee/store', [PlatformFeeController::class,'store'])->name('platform-fee.store');
    Route::get('platform-fee/edit/{id}', [PlatformFeeController::class,'edit'])->name('platform-fee.edit');
    Route::post('platform-fee/update/{id}', [PlatformFeeController::class,'update'])->name('platform-fee.update');
    Route::get('platform-fee/delete/{id}', [PlatformFeeController::class,'destroy'])->name('platform-fee.delete');

});
//Widget Routs
Route::group(['prefix' => 'widget'], function() {
    Route::get('widget-basic', [HomeController::class, 'widgetbasic'])->name('widget.widgetbasic');
    Route::get('widget-chart', [HomeController::class, 'widgetchart'])->name('widget.widgetchart');
    Route::get('widget-card', [HomeController::class, 'widgetcard'])->name('widget.widgetcard');
});

//Maps Routs
Route::group(['prefix' => 'maps'], function() {
    Route::get('google', [HomeController::class, 'google'])->name('maps.google');
    Route::get('vector', [HomeController::class, 'vector'])->name('maps.vector');
});

//Auth pages Routs
Route::group(['prefix' => 'auth'], function() {
    Route::get('signin', [HomeController::class, 'signin'])->name('auth.signin');
    Route::get('signup', [HomeController::class, 'signup'])->name('auth.signup');
    Route::get('confirmmail', [HomeController::class, 'confirmmail'])->name('auth.confirmmail');
    Route::get('lockscreen', [HomeController::class, 'lockscreen'])->name('auth.lockscreen');
    Route::get('recoverpw', [HomeController::class, 'recoverpw'])->name('auth.recoverpw');
    Route::get('userprivacysetting', [HomeController::class, 'userprivacysetting'])->name('auth.userprivacysetting');
});

//Error Page Route
Route::group(['prefix' => 'errors'], function() {
    Route::get('error404', [HomeController::class, 'error404'])->name('errors.error404');
    Route::get('error500', [HomeController::class, 'error500'])->name('errors.error500');
    Route::get('maintenance', [HomeController::class, 'maintenance'])->name('errors.maintenance');
});


//Forms Pages Routs
Route::group(['prefix' => 'forms'], function() {
    Route::get('element', [HomeController::class, 'element'])->name('forms.element');
    Route::get('wizard', [HomeController::class, 'wizard'])->name('forms.wizard');
    Route::get('validation', [HomeController::class, 'validation'])->name('forms.validation');
});


Route::middleware(['auth'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        // Item Categories
        Route::resource('item-categories', AdminItemCategoryController::class);

        // Item Subcategories
        Route::resource('item-subcategories', AdminItemSubcategoryController::class);

        // Items
        Route::resource('items', AdminItemController::class);

        // Ajax: get subcategories by category
        Route::get(
            'get-subcategories/{categoryId}',
            [AdminItemController::class, 'getSubcategories']
        )->name('get-subcategories');
    });
    

//Table Page Routs
Route::group(['prefix' => 'table'], function() {
    Route::get('bootstraptable', [HomeController::class, 'bootstraptable'])->name('table.bootstraptable');
    Route::get('datatable', [HomeController::class, 'datatable'])->name('table.datatable');
});

//Icons Page Routs
Route::group(['prefix' => 'icons'], function() {
    Route::get('solid', [HomeController::class, 'solid'])->name('icons.solid');
    Route::get('outline', [HomeController::class, 'outline'])->name('icons.outline');
    Route::get('dualtone', [HomeController::class, 'dualtone'])->name('icons.dualtone');
    Route::get('colored', [HomeController::class, 'colored'])->name('icons.colored');
});
//Extra Page Routs
Route::get('privacy-policy', [HomeController::class, 'privacypolicy'])->name('pages.privacy-policy');
Route::get('terms-of-use', [HomeController::class, 'termsofuse'])->name('pages.term-of-use');


Route::get('/admin/get-category-tax-hsn/{id}', function ($id) {
    $category = \App\Models\ItemCategory::find($id);

    return response()->json([
        'hsn' => $category->hsn,
        'tax' => $category->tax,
    ]);
});

Route::get('/admin/get-subcategory-parents/{categoryId}', function ($categoryId) {
    return \App\Models\ItemSubcategory::where('category_id', $categoryId)
        ->whereNull('parent_id') // only top level
        ->select('id','name')
        ->get();
});

require __DIR__.'/web_admin.php';