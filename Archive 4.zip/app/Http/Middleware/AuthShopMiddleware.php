<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\AppOwnerUser;
use Symfony\Component\HttpFoundation\Response;

class AuthShopMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $token = $request->bearerToken()
            ?? $request->header('X-Shop-Token')
            ?? $request->input('shop_token');

        if (!$token) {
            return response()->json(['status' => false, 'message' => 'Shop authentication required.'], 401);
        }

        $shop = AppOwnerUser::where('api_token', $token)->first();

        if (!$shop) {
            return response()->json(['status' => false, 'message' => 'Invalid shop token.'], 401);
        }

        $request->merge(['_auth_shop' => $shop]);
        $request->setUserResolver(fn () => $shop);

        return $next($request);
    }
}
