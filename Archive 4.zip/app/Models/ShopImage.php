<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShopImage extends Model
{
    protected $table    = 'shop_images';
    public $timestamps  = false;
    protected $fillable = ['shop_id', 'image_path', 'tag'];

    public function shop()
    {
        return $this->belongsTo(AppOwnerUser::class, 'shop_id', 'shop_id');
    }
}
