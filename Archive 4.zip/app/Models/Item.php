<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Item extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'shop_id', 'category_id', 'subcategory_id',
        'item_name', 'description', 'images',
        'is_veg', 'is_jain', 'spice_level', 'preparation_time',
        'is_featured', 'status',
        'commission_type', 'commission_value',
        'rating_avg', 'rating_count',
    ];

    protected $casts = [
        'images'           => 'array',
        'is_veg'           => 'boolean',
        'is_jain'          => 'boolean',
        'is_featured'      => 'boolean',
        'rating_avg'       => 'float',
        'commission_value' => 'float',
    ];

    public function variants()
    {
        return $this->hasMany(ItemVariant::class)->where('status', 'active');
    }

    public function defaultVariant()
    {
        return $this->hasOne(ItemVariant::class)->where('is_default', true)->where('status', 'active');
    }

    public function category()
    {
        return $this->belongsTo(ItemCategory::class, 'category_id');
    }

    public function subcategory()
    {
        return $this->belongsTo(ItemSubcategory::class, 'subcategory_id');
    }

    public function owner()
    {
        return $this->belongsTo(AppOwnerUser::class, 'shop_id', 'shop_id');
    }

    public function getImageUrlsAttribute(): array
    {
        return collect($this->images ?? [])->map(fn($p) => asset('storage/' . $p))->toArray();
    }
}
