<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ItemSubcategory extends Model
{
    protected $table    = 'item_subcategories';
    public $timestamps  = false;
    protected $fillable = ['category_id', 'name', 'image', 'status', 'sort_order', 'commission_percent', 'commission_type'];

    public function category()
    {
        return $this->belongsTo(ItemCategory::class, 'category_id');
    }
}
