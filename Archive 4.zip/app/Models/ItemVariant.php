<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ItemVariant extends Model
{
    protected $table = 'item_variants';
    public $timestamps = false;

    protected $fillable = [
        'item_id', 'label', 'price', 'offer_price', 'gst_percent',
        'hsn_code', 'is_default', 'status',
    ];

    protected $casts = [
        'price'       => 'decimal:2',
        'offer_price' => 'decimal:2',
        'gst_percent' => 'decimal:2',
        'is_default'  => 'boolean',
    ];

    public function item()
    {
        return $this->belongsTo(Item::class);
    }
}
