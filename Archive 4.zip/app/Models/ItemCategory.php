<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ItemCategory extends Model
{
    protected $table    = 'item_categories';
    public $timestamps  = false;
    protected $fillable = ['category_name', 'image', 'status', 'sort_order', 'commission_percent', 'commission_type'];
}
